# menu.py
menu_items = [
    {"name": "Home", "url": "/"},
    {"name": "Config. Sup. Data", "url": "/suppdataconfig"},
    {"name": "Detalhe Sup. Data", "url": "/suppdatadet"},
    {"name": "Projetos", "url": "/projeto"},
    {"name": "Usuários", "url": "/users"},
    {"name": "Gerar Form", "url": "/generate-code"},
    {"name": "Data Source", "url": "/datasource"},
    {"name": "Sobre", "url": "/about"},
    {"name": "Sair", "url": "/logout"}
]